#!/bin/sh

current_dir=`pwd`
db_config_file="../resources/products/DB/DB.txt"
#working_dir=`grep "RUNCMD" $db_config_file | cut -d "=" -f2 | cut -d "|" -f1 | sed 's/db_main//g'`
#output_dir=`grep "CMDOUTFILE" $db_config_file | cut -d "=" -f2  | cut -d "|" -f1 | sed 's/\*//g'`
working_dir="../resources/util/DB"
output_dir="$current_dir/output"
log_dir="$current_dir/output/logs"

if [ ! -d "$output_dir" ] ; then
	mkdir -p "$output_dir" 
fi

if [ ! -d "$log_dir" ] ; then
	mkdir "$log_dir"
else
	rm -f "${log_dir}"/DB_*.log
	rm -f "${log_dir}"/EBS_*.log
fi


echo $ALLPRODLIST | grep "EBS" > /dev/null
if [ $? = 0 ]; then
	vprodlist="DB~EBS"		
else
	vprodlist="DB"		
fi	

export vprodlist

cd "$working_dir"
chmod +x *.sh

if [ -f oracle_homes_a.txt ] ; then
 rm -f oracle_homes_*.txt
fi

if [ "$LICAGREE" = "YES" ]; then
	./look_for_running_sids.sh "db_conn_coll_main.sql YES $vprodlist"
else
	./look_for_running_sids.sh "db_conn_coll_main.sql NO $vprodlist"
fi

./db_conn_coll.sh NO db_list.csv
./logcolstat.sh ALL YES

rm -f *_sql_*.log

for log in `ls *.log`
do
if [ ! -s $log ]; then
	rm -f $log
fi
done 

for f in DB DBA_FUS EBS
do
if [ -d "$f" ]; then
	cp -pR "$f" "$output_dir/."
	ls -Rl "$output_dir/$f" >>db_conn_coll.log
	rm -rf "$f"
fi	
done

cp *.log "$log_dir/."
cp *.csv "$log_dir/."

cd "$current_dir"