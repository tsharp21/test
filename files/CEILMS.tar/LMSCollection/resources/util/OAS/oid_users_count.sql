REM Script version: 16.2
REM The following privileges are needed to run this script:
REM grant create session
REM grant select on sys.v_$instance
REM grant select on sys.dba_users
REM grant select on sys.dba_tables
REM grant select on sys.v_$version
REM grant select on <<oid schema>>.ods_process        --ver 10g
REM grant select on <<oid schema>>.ods_process_status --ver 11g
REM grant select on <<oid schema>>.ds_attrstore
REM grant select on <<oid schema>>.ct_objectclass
REM grant select on <<oid schema>>.ct_tombstone

-- PREPARE AND DISPLAY LICENSE AGREEMENT
SET TERMOUT OFF
SET ECHO OFF

SPOOL lms_license_agreement.txt

PROMPT ===============================================================
PROMPT For reading LICENSE AGREEMENT use:
PROMPT <SPACE>  to display next page
PROMPT <RETURN> to display next line
PROMPT ===============================================================
PROMPT
PROMPT Oracle License Management Services 
PROMPT License Agreement
PROMPT  
PROMPT PLEASE SCROLL DOWN AND READ ALL OF THE FOLLOWING TERMS AND CONDITIONS OF THIS 
PROMPT LICENSE AGREEMENT ("Agreement") CAREFULLY BEFORE DEMONSTRATING YOUR ACCEPTANCE 
PROMPT BY CLICKING AN "ACCEPT LICENSE AGREEMENT" OR SIMILAR BUTTON OR BY TYPING THE 
PROMPT REQUIRED ACCEPTANCE TEXT OR INSTALLING OR USING THE PROGRAMS 
PROMPT (AS DEFINED BELOW). 
PROMPT 
PROMPT THIS AGREEMENT IS A LEGALLY BINDING CONTRACT BETWEEN YOU AND ORACLE AMERICA, 
PROMPT INC. THAT SETS FORTH THE TERMS AND CONDITIONS THAT GOVERN YOUR USE OF THE 
PROMPT PROGRAMS.  BY DEMONSTRATING YOUR ACCEPTANCE BY CLICKING AN "ACCEPT LICENSE 
PROMPT AGREEMENT" OR SIMILAR BUTTON OR BY TYPING THE REQUIRED ACCEPTANCE TEXT OR 
PROMPT INSTALLING AND/OR USING THE PROGRAMS, YOU AGREE TO ABIDE BY ALL OF THE TERMS 
PROMPT AND CONDITIONS STATED OR REFERENCED HEREIN.  
PROMPT 
PROMPT IF YOU DO NOT AGREE TO ABIDE BY THESE TERMS AND CONDITIONS, DO NOT DEMONSTRATE 
PROMPT YOUR ACCEPTANCE BY THE SPECIFIED MEANS AND DO NOT INSTALL OR USE THE PROGRAMS. 
PROMPT 
PROMPT YOU MUST ACCEPT AND ABIDE BY THESE TERMS AND CONDITIONS AS PRESENTED TO 
PROMPT YOU - ANY CHANGES, ADDITIONS OR DELETIONS BY YOU TO THESE TERMS AND CONDITIONS 
PROMPT WILL NOT BE ACCEPTED BY US AND WILL NOT MAKE PART OF THIS AGREEMENT.   
PROMPT THE TERMS AND CONDITIONS SET FORTH IN THIS AGREEMENT SUPERSEDE ANY OTHER 
PROMPT LICENSE TERMS APPLICABLE TO YOUR USE OF THE PROGRAMS.
PROMPT 
PROMPT Definitions
PROMPT 
PROMPT "We," "us," and "our" refers to Oracle America, Inc.  
PROMPT "Oracle" refers to Oracle Corporation and its affiliates.  
PROMPT 
PROMPT "You" and "your" refers to the individual or entity that wishes to use the 
PROMPT programs (as defined below) provided by Oracle. 
PROMPT 
PROMPT "Programs" or "programs" refers to the tool(s), script(s) and/or software 
PROMPT product(s) and any applicable program documentation provided to you by Oracle 
PROMPT which you wish to access and use to measure, monitor and/or manage your usage 
PROMPT of separately-licensed Oracle software. 
PROMPT 
PROMPT 
PROMPT Rights Granted
PROMPT 
PROMPT We grant you a non-exclusive, non-transferable limited right to use the 
PROMPT programs, subject to the terms of this agreement, for the limited purpose of 
PROMPT measuring, monitoring and/or managing your usage of separately-licensed 
PROMPT Oracle software.  You may allow your agents and contractors (including, without
PROMPT limitation, outsourcers) to use the programs for this purpose and you are 
PROMPT responsible for their compliance with this agreement in such use.  
PROMPT You (including your agents, contractors and/or outsourcers) may not use the 
PROMPT programs for any other purpose. 
PROMPT 
PROMPT Ownership and Restrictions 
PROMPT 
PROMPT Oracle and Oracle's licensors retain all ownership and intellectual property 
PROMPT rights to the programs. The programs may be installed on one or more servers; 
PROMPT provided, however, that you may only make one copy of the programs for 
PROMPT backup or archival purposes. 
PROMPT 
PROMPT Third party technology that may be appropriate or necessary for use with the 
PROMPT programs is specified in the program documentation, notice files or readme 
PROMPT files.  Such third party technology is licensed to you under the terms of the 
PROMPT third party technology license agreement specified in the program 
PROMPT documentation, notice files or readme files and not under the terms of this 
PROMPT agreement.    
PROMPT 
PROMPT You may not:
PROMPT - use the programs for your own internal data processing or for any 
PROMPT   commercial or production purposes, or use the programs for any purpose 
PROMPT   except the purpose stated herein; 
PROMPT - remove or modify any program markings or any notice of Oracle's or Oracle's
PROMPT   licensors' proprietary rights;
PROMPT - make the programs available in any manner to any third party for use in the
PROMPT   third party's business operations, without our prior written consent;  
PROMPT - use the programs to provide third party training or rent or lease the 
PROMPT   programs or use the programs for commercial time sharing or service bureau 
PROMPT   use; 
PROMPT - assign this agreement or give or transfer the programs or an interest in 
PROMPT   them to another individual or entity; 
PROMPT - cause or permit reverse engineering (unless required by law for 
PROMPT   interoperability), disassembly or decompilation of the programs (the 
PROMPT   foregoing prohibition includes but is not limited to review of data 
PROMPT   structures or similar materials produced by programs);
PROMPT - disclose results of any program benchmark tests without our prior written 
PROMPT   consent; 
PROMPT - use any Oracle name, trademark or logo without our prior written consent.
PROMPT 
PROMPT Disclaimer of Warranty
PROMPT 
PROMPT ORACLE DOES NOT GUARANTEE THAT THE PROGRAMS WILL PERFORM ERROR-FREE OR 
PROMPT UNINTERRUPTED. TO THE EXTENT NOT PROHIBITED BY LAW, THE PROGRAMS ARE PROVIDED 
PROMPT "AS IS" WITHOUT WARRANTY OF ANY KIND AND THERE ARE NO WARRANTIES, EXPRESS OR 
PROMPT IMPLIED, OR CONDITIONS, INCLUDING WITHOUT LIMITATION, WARRANTIES OR CONDITIONS 
PROMPT OF MERCHANTABILITY, NONINFRINGEMENT OR FITNESS FOR A PARTICULAR PURPOSE THAT 
PROMPT APPLY TO THE PROGRAMS. 
PROMPT 
PROMPT No Right to Technical Support
PROMPT You acknowledge and agree that Oracle's technical support organization will 
PROMPT not provide you with technical support for the programs licensed under this 
PROMPT agreement.  
PROMPT 
PROMPT End of Agreement
PROMPT You may terminate this agreement by destroying all copies of the programs. 
PROMPT We have the right to terminate your right to use the programs at any time upon 
PROMPT notice to you, in which case you shall destroy all copies of the programs. 
PROMPT 
PROMPT Entire Agreement
PROMPT You agree that this agreement is the complete agreement for the programs and 
PROMPT supersedes all prior or contemporaneous agreements or representations, written 
PROMPT or oral, regarding such programs. If any term of this agreement is found to be 
PROMPT invalid or unenforceable, the remaining provisions will remain effective and 
PROMPT such term shall be replaced with a term consistent with the purpose and intent 
PROMPT of this agreement. 
PROMPT 
PROMPT Limitation of Liability
PROMPT IN NO EVENT SHALL ORACLE BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL, 
PROMPT PUNITIVE OR CONSEQUENTIAL DAMAGES, OR ANY LOSS OF PROFITS, REVENUE, DATA OR 
PROMPT DATA USE, INCURRED BY YOU OR ANY THIRD PARTY.  ORACLE'S ENTIRE LIABILITY FOR 
PROMPT DAMAGES ARISING OUT OF OR RELATED TO THIS AGREEMENT, WHETHER IN CONTRACT OR 
PROMPT TORT OR OTHERWISE, SHALL IN NO EVENT EXCEED ONE THOUSAND U.S. DOLLARS 
PROMPT (U.S. $1,000).  
PROMPT 
PROMPT Export 
PROMPT 
PROMPT Export laws and regulations of the United States and any other relevant local 
PROMPT export laws and regulations apply to the programs.  You agree that such export 
PROMPT control laws govern your use of the programs (including technical data) 
PROMPT provided under this agreement, and you agree to comply with all such export 
PROMPT laws and regulations (including "deemed export" and "deemed re-export" 
PROMPT regulations). You agree that no data, information, and/or program (or direct 
PROMPT product thereof) will be exported, directly or indirectly, in violation of any 
PROMPT export laws, nor will they be used for any purpose prohibited by these laws 
PROMPT including, without limitation, nuclear, chemical, or biological weapons 
PROMPT proliferation, or development of missile technology.   
PROMPT 
PROMPT Other
PROMPT 
PROMPT 1.  This agreement is governed by the substantive and procedural laws of the 
PROMPT     State of California. You and we agree to submit to the exclusive 
PROMPT     jurisdiction of, and venue in, the courts of San Francisco or Santa Clara 
PROMPT     counties in California in any dispute arising out of or relating to this 
PROMPT     agreement. 
PROMPT 2.  You may not assign this agreement or give or transfer the programs or an 
PROMPT     interest in them to another individual or entity.  If you grant a security 
PROMPT     interest in the programs, the secured party has no right to use or transfer
PROMPT     the programs.
PROMPT 3.  Except for actions for breach of Oracle's proprietary rights, no action, 
PROMPT     regardless of form, arising out of or relating to this agreement may be 
PROMPT     brought by either party more than two years after the cause of action has 
PROMPT     accrued.
PROMPT 4.  Oracle may audit your use of the programs.  You agree to cooperate with 
PROMPT     Oracle's audit and provide reasonable assistance and access to information.
PROMPT     Any such audit shall not unreasonably interfere with your normal business 
PROMPT     operations.  You agree that Oracle shall not be responsible for any of your
PROMPT     costs incurred in cooperating with the audit.    
PROMPT 5.  The relationship between you and us is that of licensee/licensor. 
PROMPT     Nothing in this agreement shall be construed to create a partnership, joint
PROMPT     venture, agency, or employment relationship between the parties.  
PROMPT     The parties agree that they are acting solely as independent contractors 
PROMPT     hereunder and agree that the parties have no fiduciary duty to one another 
PROMPT     or any other special or implied duties that are not expressly stated herein.
PROMPT     Neither party has any authority to act as agent for, or to incur any 
PROMPT     obligations on behalf of or in the name of the other.  
PROMPT 6.  This agreement may not be modified and the rights and restrictions may not 
PROMPT     be altered or waived except in a writing signed by authorized 
PROMPT     representatives of you and of us.  
PROMPT 7.  Any notice required under this agreement shall be provided to the other 
PROMPT     party in writing.
PROMPT 
PROMPT Contact Information
PROMPT Should you have any questions concerning your use of the programs or this 
PROMPT agreement, please contact: 
PROMPT 
PROMPT License Management Services at:
PROMPT http://www.oracle.com/us/corporate/license-management-services/index.html
PROMPT Oracle America, Inc.
PROMPT 500 Oracle Parkway, 
PROMPT Redwood City, CA 94065 
PROMPT

SPOOL OFF

HOST more lms_license_agreement.txt
HOST rm   lms_license_agreement.txt
HOST del  lms_license_agreement.txt

-- PROMT FOR LICENSE AGREEMENT ACCEPTANCE
DEFINE LANSWER=N
SET TERMOUT ON
ACCEPT LANSWER FORMAT A1 PROMPT 'Accept License Agreement? (y\n): '

SET TERMOUT OFF
WHENEVER SQLERROR EXIT
select 1/decode('&LANSWER', 'Y', null, 'y', null, decode('', null, 0, null)) as " " from dual;
PROMPT 

-- PROMT FOR USER LIST
DEFINE UANSWER=N
SET TERMOUT ON
ACCEPT UANSWER FORMAT A1 PROMPT 'List all users? (y\n): '
SET TERMOUT OFF

-- PROMT FOR BASE_DN
SET TERMOUT ON
ACCEPT BDN_ANSWER PROMPT 'Enter BASE_DN: '
SET TERMOUT OFF


WHENEVER SQLERROR CONTINUE

SET TERMOUT ON
SET FEEDBACK ON
SET LINESIZE 160
SET SERVEROUTPUT ON SIZE 1000000
SET SERVEROUTPUT ON SIZE UNLIMITED
SET VERIFY OFF

column host_name new_value v_h_name
column instance_name new_value v_i_name
select host_name, instance_name from sys.v_$instance;

SPOOL results-oid-users-count-&v_h_name-&v_i_name..txt;

PROMPT =================================================================================
PROMPT Script Name=oid_users_count_v13_2_1.sql
PROMPT =================================================================================
PROMPT 

select host_name, instance_name from sys.v_$instance;

SELECT banner FROM sys.v_$version WHERE banner like 'Oracle%';

select USERNAME, ACCOUNT_STATUS, LOCK_DATE, EXPIRY_DATE, CREATED from SYS.DBA_USERS where username='ODS';

-- Querying table ODS_PROCESS or ODS_PROCESS_SYSTEM

DECLARE
	N_ODS_PROCESS NUMBER;
	N_ODS_PROCESS_STATUS NUMBER;
BEGIN

	SYS.DBMS_OUTPUT.PUT_LINE('Querying table ODS_PROCESS (for version 10g) ...');
	SELECT COUNT(*) INTO N_ODS_PROCESS FROM SYS.DBA_TABLES WHERE OWNER = 'ODS' AND TABLE_NAME = 'ODS_PROCESS'; 
	
	IF (N_ODS_PROCESS > 0) THEN
		DECLARE
		ODS_PROC_CURSOR NUMBER := SYS.DBMS_SQL.OPEN_CURSOR;
		L_HOSTNAME    VARCHAR2(255);
		L_RESULTS NUMBER;
		BEGIN
			SYS.DBMS_SQL.PARSE(ODS_PROC_CURSOR,'SELECT DISTINCT HOSTNAME FROM ODS.ODS_PROCESS',SYS.DBMS_SQL.NATIVE);
			SYS.DBMS_SQL.DEFINE_COLUMN(ODS_PROC_CURSOR, 1, L_HOSTNAME, 255);
			L_RESULTS := SYS.DBMS_SQL.EXECUTE(ODS_PROC_CURSOR);
			SYS.DBMS_OUTPUT.PUT_LINE('HOSTNAME');
			SYS.DBMS_OUTPUT.PUT_LINE('-----------------------------');
			LOOP
			IF SYS.DBMS_SQL.FETCH_ROWS(ODS_PROC_CURSOR) > 0 THEN
				SYS.DBMS_SQL.COLUMN_VALUE(ODS_PROC_CURSOR, 1, L_HOSTNAME);
				SYS.DBMS_OUTPUT.PUT_LINE(L_HOSTNAME);
			ELSE
				EXIT;
			END IF;
		  END LOOP;
			SYS.DBMS_SQL.CLOSE_CURSOR(ODS_PROC_CURSOR);
			SYS.DBMS_OUTPUT.PUT_LINE(CHR(10));
		END;
	ELSE
		SYS.DBMS_OUTPUT.PUT_LINE('--- Table ODS_PROCESS not found.');
		SYS.DBMS_OUTPUT.PUT_LINE(CHR(10));
	END IF;

	SYS.DBMS_OUTPUT.PUT_LINE('Querying table ODS_PROCESS_STATUS (for version 11g) ...');

	SELECT COUNT(*) INTO N_ODS_PROCESS_STATUS	FROM SYS.DBA_TABLES	WHERE OWNER = 'ODS' AND TABLE_NAME = 'ODS_PROCESS_STATUS'; 
	
	IF (N_ODS_PROCESS_STATUS > 0) THEN
		DECLARE
		ODS_PROC_ST_CURSOR NUMBER := SYS.DBMS_SQL.OPEN_CURSOR;
		L_HOSTNAME    VARCHAR2(255);
		L_RESULTS NUMBER;
		BEGIN
		  SYS.DBMS_SQL.PARSE(ODS_PROC_ST_CURSOR,'SELECT DISTINCT HOSTNAME FROM ODS.ODS_PROCESS_STATUS', SYS.DBMS_SQL.NATIVE);
		  SYS.DBMS_SQL.DEFINE_COLUMN(ODS_PROC_ST_CURSOR, 1, L_HOSTNAME, 255);
		  L_RESULTS := SYS.DBMS_SQL.EXECUTE(ODS_PROC_ST_CURSOR);
		  SYS.DBMS_OUTPUT.PUT_LINE('HOSTNAME');
		  SYS.DBMS_OUTPUT.PUT_LINE('-----------------------------');
		  LOOP
			IF SYS.DBMS_SQL.FETCH_ROWS(ODS_PROC_ST_CURSOR) > 0 THEN
				SYS.DBMS_SQL.COLUMN_VALUE(ODS_PROC_ST_CURSOR, 1, L_HOSTNAME);
				SYS.DBMS_OUTPUT.PUT_LINE(L_HOSTNAME);
			ELSE
				EXIT;
			END IF;
		  END LOOP;
		  SYS.DBMS_SQL.CLOSE_CURSOR(ODS_PROC_ST_CURSOR);
		  SYS.DBMS_OUTPUT.PUT_LINE(CHR(10));
		END;
	ELSE
		SYS.DBMS_OUTPUT.PUT_LINE('--- Table ODS_PROCESS_STATUS not found.');
		SYS.DBMS_OUTPUT.PUT_LINE(CHR(10));
	END IF;

	IF (( '&UANSWER' = 'y' ) OR ( '&UANSWER' = 'Y' )) THEN
		DECLARE
		ATTRVAL_CURSOR NUMBER := SYS.DBMS_SQL.OPEN_CURSOR;
		ROWS_PROCESSED INTEGER;
		V_ATTRVAL VARCHAR2(500);
		BEGIN
			SYS.DBMS_OUTPUT.PUT_LINE ('=================================================================================');
			SYS.DBMS_SQL.PARSE(ATTRVAL_CURSOR,'SELECT S.ATTRVAL FROM ODS.DS_ATTRSTORE S, ODS.CT_OBJECTCLASS O WHERE S.ATTRNAME = ''orclentrydn'' AND O.ATTRVALUE = ''inetorgperson'' AND S.ENTRYID = O.ENTRYID',DBMS_SQL.NATIVE);
			SYS.DBMS_SQL.DEFINE_COLUMN(ATTRVAL_CURSOR, 1, V_ATTRVAL, 500);
			ROWS_PROCESSED := SYS.DBMS_SQL.EXECUTE ( ATTRVAL_CURSOR );
			SYS.DBMS_OUTPUT.PUT_LINE(CHR(10));
			SYS.DBMS_OUTPUT.PUT_LINE ('USERS');
			SYS.DBMS_OUTPUT.PUT_LINE ('---------------------');
			LOOP
				IF SYS.DBMS_SQL.FETCH_ROWS(ATTRVAL_CURSOR) > 0 THEN
					SYS.DBMS_SQL.COLUMN_VALUE (ATTRVAL_CURSOR, 1, V_ATTRVAL);
					SYS.DBMS_OUTPUT.PUT_LINE (V_ATTRVAL);
				ELSE
					EXIT;
				END IF;
			END LOOP;
			SYS.DBMS_SQL.CLOSE_CURSOR(ATTRVAL_CURSOR);
			SYS.DBMS_OUTPUT.PUT_LINE(CHR(10));
		END;
	END IF;	
	
END;
/

PROMPT =================================================================================
PROMPT
PROMPT Number of records from ODS.DS_ATTRSTORE joined with ODS.CT_OBJECTCLASS for BASE_DN: &BDN_ANSWER
SELECT COUNT(*) FROM ODS.DS_ATTRSTORE STORE, ODS.CT_OBJECTCLASS OBJ WHERE STORE.ATTRNAME = 'orclentrydn' AND OBJ.ATTRVALUE = 'inetorgperson' AND STORE.ENTRYID = OBJ.ENTRYID AND REPLACE(LOWER(STORE.ATTRVAL),' ') LIKE REPLACE(LOWER('%&BDN_ANSWER'),' ');

PROMPT =================================================================================
PROMPT
PROMPT Number of records from ODS.DS_ATTRSTORE joined with ODS.CT_OBJECTCLASS
SELECT COUNT(*) FROM ODS.DS_ATTRSTORE STORE, ODS.CT_OBJECTCLASS OBJ WHERE STORE.ATTRNAME = 'orclentrydn' AND OBJ.ATTRVALUE = 'inetorgperson' AND STORE.ENTRYID = OBJ.ENTRYID;

PROMPT =================================================================================
PROMPT
PROMPT Number of records from ODS.CT_TOMBSTONE table:

SELECT COUNT(*) FROM ODS.CT_TOMBSTONE;

SPOOL OFF
QUIT