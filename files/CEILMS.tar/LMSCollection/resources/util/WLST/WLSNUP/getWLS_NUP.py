# getWLS_NUP.py v17.2
# This script will:
# * connect WLST to the WLS Domain 
# * get a list of users who can access the Domain
# * get a count of the number of authorized users for each Group
#

from weblogic.management.security.authentication import UserReaderMBean
from weblogic.management.security.authentication import GroupReaderMBean
from weblogic.management.security.authentication import GroupMemberListerMBean
from weblogic.management.security.authentication import GroupUserListerMBean

from java.io import File
from java.io import FileOutputStream
import os


NUP_script_version = "17.2"

def getNUP_Info(targetMachine, domainName, host, adminName, password):

	print
	print 'Oracle License Management Services WebLogic NUP script version ' + NUP_script_version
	print


	print 'Trying to connect to Machine ' + targetMachine + ' Domain ' + domainName	
	try: 
		connect(adminName, password, host)

	except WLSTException, ex:
		print 'Failed to connect to Machine ' + targetMachine + ' Domain ' + domainName
		print 'Exception:', ex
		return str(ex)
		
	## We need to only get  NUP from WebLogic 9.X and later
	ver=cmo.getConfigurationVersion()
	
	verElements = ver.split('.')
	if eval(verElements[0]) < 9 :
		print 'Failed to connect. NUP measurement not supported on WebLogic Version' + ver + ' running on ' + targetMachine + ' Domain ' + domainName 

		print
		print 'End of getWLS_NUP'
		return 2 
	else:
		print "WebLogic Version " + ver

	## Loop through each security realm and each authentication provider and get the user names
	try:
		securityRealms=cmo.getSecurityConfiguration().getRealms()
		for r in securityRealms:
			authenticationProviders = r.getAuthenticationProviders()
			providerCount = 0
			
			for i in authenticationProviders:
				if isinstance(i,GroupReaderMBean):
					groupReader = i
					groupCursor =  i.listGroups("*",0)
					groupCount = 0
					print 'Security Realm:'+r.getName()+' Provider:'+i.getName() + ' groups and users are: '
					while groupReader.haveCurrent(groupCursor):
						currGrpName = groupReader.getCurrentName(groupCursor)
						usergroup = None
						usrCount = 0;
						print '\tGroup: ' + currGrpName + ' Users are: '
						if isinstance(i,GroupUserListerMBean):
							usergroup = i.listAllUsersInGroup(currGrpName,"*",0)
							for user in usergroup:
								print '\t\t\t' + user
								usrCount = usrCount + 1
						elif isinstance(i,GroupMemberListerMBean):
							members = i.listGroupMembers(currGrpName,"*",0)
							while i.haveCurrent(members):
								user=i.getCurrentName(members)
								if i.userExists(user):
									print '\t\t\t' + user
									usrCount = usrCount + 1
								i.advance(members)
							i.close(members)
						print '\tTotal Users in Group ' + currGrpName + ' are: ' + str(usrCount) + '\n\n'
						groupReader.advance(groupCursor)
						groupCount = groupCount + 1
					groupReader.close(groupCursor)
					print 'Total Groups in Authentication Provider ' + i.getName()+' are: '+ str(groupCount)
					providerCount = providerCount + 1

			print 'Total Authentication Providers in Security Realm ' +r.getName()+' are: '+ str(providerCount)

		disconnect()
		return 1
	except WLSTException, ex:
		print 'WLST Failed.  Could not get NUP Information from Domain ' + domainName + ':' + ex
		print 'End of getWLS_NUP'
		return str(ex)

	
def useWLS_FileArgs(inputFile):

	inFile = open(inputFile)
	print 'Opening Input File: ' + inputFile
	print
	print 'WLS NUP LMS Measurement v' + NUP_script_version

	## loop through the file and call get_NUP_Info() for each entry
	for inLine in inFile.readlines():
		
		if inLine.strip().startswith('#'):
			continue
		elif inLine.strip().startswith("WLS_HOME="):
			continue
		else:
			vars = inLine.split(',')
			vars = [var.strip() for var in vars]

			## Check for an empty Line
			if len(vars) <= 1:
				continue

			## Make sure we got our 5 variables
			if len(vars) != 5:
				print 'Invalid Input Line: ' + inLine
				continue
			else:
				(targetMachine, domainName, hostURL, adminName, password) = vars
				host = "t3://%s" %hostURL
			
			fBaseName = targetMachine + '_' + domainName + '_OracleWLS_NUP.txt'
			
			theInterpreter.setOut(prev)
			print 'Reading users for the domain, ' + domainName + ', the time to complete this command will depend on the number of users.'
			

			NUP_output = File(os.getcwd() + os.sep + 'output' + os.sep + 'WLSNUP' + os.sep + fBaseName)
			print 'Saving output to ' + str(NUP_output)
		
			fosNUPOut = FileOutputStream(NUP_output)
			theInterpreter.setOut(fosNUPOut)
			
			print  
			print 'WLST Input Information' 
			print 'Domain Name: ' + domainName 
			print 'Target Machine: ' + targetMachine
			print 'Host URL: ' + hostURL
			print 'WL_HOME: ' + os.environ["WL_HOME"]

			print
			
			WLST_return = getNUP_Info(targetMachine, domainName, hostURL, adminName, password)
			
			
			NUP_ERRORS = File(os.getcwd() + os.sep + 'output' + os.sep + 'logs' + os.sep + 'WLS_errors.log')
			fosNUPerr = FileOutputStream(NUP_ERRORS,true)

			NUP_WARNINGS = File(os.getcwd() + os.sep + 'output' + os.sep + 'logs' + os.sep + 'WLS_warnings.log')
			fosNUPwarn = FileOutputStream(NUP_WARNINGS,true)

			NUP_COLLECTED = File(os.getcwd() + os.sep + 'output' + os.sep + 'logs' + os.sep + 'WLS_collected.log')
			fosNUPcol = FileOutputStream(NUP_COLLECTED,true)

			
			
			print 
			
			if WLST_return == 1:
				theInterpreter.setOut(fosNUPcol)
				print 'WLS: LMS-03200: COLLECTED: NUP measurement running on ' + targetMachine + ' Domain ' + domainName
			elif WLST_return.find('authenticated') >= 0:
				theInterpreter.setOut(fosNUPerr)
				print 'WLS: LMS-03000: ERROR: WLSNUP script failed to authenticate user for URL: ' + hostURL + ', domain: ' + domainName + '.  Invalid userID or password.'
			elif WLST_return.find('performing') >= 0:
				theInterpreter.setOut(fosNUPerr)
				print 'WLS: LMS-03001: ERROR: WLSNUP script failed to connect to URL: ' + hostURL + ', domain: ' + domainName + '.  Please check the URL and port and try again.'
			elif WLST_return == 2:
				theInterpreter.setOut(fosNUPerr)
				print 'WLS: LMS-03002: ERROR: WLSNUP script failed to connect to URL: ' + hostURL + ', domain: ' + domainName + ', this version of WebLogic is not supported by the WLST NUP script.'
			
			theInterpreter.setOut(fosNUPOut)
			print 
			print 'End of getWLS_NUP'
			fosNUPOut.close()
			fosNUPerr.close()
			fosNUPwarn.close()
			fosNUPcol.close()
			theInterpreter.setOut(prev)


## getWLS_nup 
##

prev = theInterpreter.getOut()

useWLS_FileArgs(sys.argv[1])

theInterpreter.setOut(prev)

print 
print 'End of getWLS_NUP'

exit()
