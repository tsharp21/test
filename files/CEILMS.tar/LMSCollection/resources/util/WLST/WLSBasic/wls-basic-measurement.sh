#!/bin/sh

SCRIPT_VERSION="17.2($LMSCT_BUILD_VERSION)"
SCRIPT_NAME=${0}
##########################################################################################
##   wls-basic-measurement     v 17.2
##    - Invoke WLS Basic feature usage script.  Connects to a running WLS server and 
##		returns WLS Basic feature usage information.
##
##  EXAMPLES
##    $ wls-basic-measurement
##


##############################################################
# make echo more portable
#

echo_Basic_printer() {
  #IFS=" " command 
  eval 'printf "%b\n" "$*"'
} 

##############################################################
# make echo more portable
#

echo_basic_log() {
	$ECHO_BASIC_PRINTER "$1" 
	$ECHO_BASIC_PRINTER "$1" >> $2
} 


# set up $ECHO
ECHO_BASIC_PRINTER="echo_Basic_printer"

################################################################################
#
# output welcome message.
#

beginMsg()
{
cat license_agreement.txt | more
ANSWER=

$ECHO_BASIC_PRINTER "Accept License Agreement? "
	while [ -z "${ANSWER}" ]
	do
		$ECHO_BASIC_PRINTER "$1 [y/n/q]: \c" >&2
  	read ANSWER
		#
		# Act according to the user's response.
		#
		case "${ANSWER}" in
			Y|y)
				return 0     # TRUE
				;;
			N|n|Q|q)
				exit 1     # FALSE
				;;
			#
			# An invalid choice was entered, reprompt.
			#
			*) ANSWER=
				;;
		esac
	done
}


################################################################################
#
#*********************************** MAIN **************************************
#
################################################################################

# command line defaults
SCRIPT_OPTIONS=


STANDALONE=
# check to see if LMSCollection is running, if not then print license. also skip ECHO setup
ps -eaf | grep LMS*.sh | grep -v grep >/dev/null 2>&1
if [ $? -eq 0 ] ; then
	STANDALONE="false"
else
	STANDALONE="true"
fi

if [ "${STANDALONE}" = "true" ] ; then
	
	# print welcome message
	beginMsg 
fi

PYFILE=../resources/util/WLST/WLSBasic/wls-basic-measurement.py
INFILE=../resources/util/WLST/wlstInput.txt
TEMPLATE=../resources/util/WLST/default_template.txt
WLS_COLLECTED=./output/logs/WLS_collected.log
WLS_WARNINGS=./output/logs/WLS_warnings.log
WLS_ERRORS=./output/logs/WLS_errors.log

QUIT_WLST=
INPUTCHANGED=
COMPARE_RESULT_FILE=compare_result.txt

if [ -f $COMPARE_RESULT_FILE ]
then
	QUIT_WLST=`cat $COMPARE_RESULT_FILE| grep QUIT_WLST | sed -e 's/QUIT_WLST=//g'`
fi

if [ "${LICAGREE}" != "YES" ] 
then
	while [ -z "${INPUTCHANGED}" -a -z "${QUIT_WLST}" ]
	do
		if cmp -s $INFILE $TEMPLATE ; then
			$ECHO_BASIC_PRINTER "\nThe file wlstInput.txt has not been updated to include the values needed to connect to your WebLogic domain(s).  \nPlease do so at this time in a separate text editor. Then return to this window and press ENTER to continue or q to quit...\n"

			read QUIT_WLST
		
			if [ "${QUIT_WLST}" = "q" -o "${QUIT_WLST}" = "quit" -o "${QUIT_WLST}" = "Q" ]; then
				QUIT_WLST="yes"
				echo QUIT_WLST="yes" > $COMPARE_RESULT_FILE
			else
				QUIT_WLST=
			fi
		else
		   INPUTCHANGED="true"
		fi
	done
fi

WL_HOME="$WL_HOME"
WLS_HOME=`cat $INFILE | grep WLS_HOME | grep -v '#' | sed -e 's/WLS_HOME=//g'`
read_from_file=0


while [ -z "${WL_HOME}" -a -z "${QUIT_WLST}" ]
do
	if [ "${read_from_file}" = 0 ] ; then
		WL_HOME="$WLS_HOME"
		read_from_file=1
	fi
	echo "$WL_HOME"
	
	if [ "${LICAGREE}" != "YES" ] 
	then
		if [ -z "${WL_HOME}" ] ; then
			$ECHO_BASIC_PRINTER "Please enter the location where WebLogic is installed">&2
			$ECHO_BASIC_PRINTER "or to quit the WebLogic Basic script, enter [quit or q]: \n" >&2
			read WL_HOME
		fi
		
		if [ "${WL_HOME}" = "q" -o "${WL_HOME}" = "quit" -o "${WL_HOME}" = "Q" ]; then
			QUIT_WLST="yes"
			echo QUIT_WLST="yes" > $COMPARE_RESULT_FILE	
		elif [ ! -f "${WL_HOME}/server/bin/setWLSEnv.sh" ]; then 
			$ECHO_BASIC_PRINTER "\nWebLogic Environment setup script, setWLSEnv.sh does not exist in ${WL_HOME}/server/bin/ .\nPlease try again.\n"
			WL_HOME=
		fi
	else
		QUIT_WLST="yes"
		echo QUIT_WLST="yes" > $COMPARE_RESULT_FILE	
	fi

done


if [ "${QUIT_WLST}" = "yes" ]; then
	rmdir ./output/WLSBasic 2>/dev/null
	if [ "${LICAGREE}" != "YES" ] 
	then
		echo_basic_log "LMSCT: WLS-03001: WARNING: User chose to quit WL Basic measurement script." $WLS_WARNINGS
	else
		echo_basic_log "LMSCT: WLS-03102: WARNING: User ran WL Basic measurement script with -L Y but did not update wlstInput.txt." $WLS_WARNINGS
	fi
		
else
	. "${WL_HOME}/server/bin/setWLSEnv.sh"
	
	if [ ! -d ./output/WLSBasic ] ; then
		mkdir -p ./output/WLSBasic 
	fi	

	java weblogic.WLST ${PYFILE} ${INFILE}
fi



