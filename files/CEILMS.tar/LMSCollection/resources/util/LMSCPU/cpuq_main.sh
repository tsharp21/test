#!/bin/sh

current_dir=`pwd`
working_dir="../resources/util/LMSCPU"
output_dir="$current_dir/output/LMSCPU"
log_dir="$current_dir/output/logs"

if [ ! -d "$output_dir" ] ; then
	mkdir -p "$output_dir" 
fi

if [ ! -d "$log_dir" ] ; then
	mkdir "$log_dir"
else
	rm -f "$log_dir/LMSCPU_*.log"
fi

cd "$working_dir"
chmod +x *.sh

./lms_cpuq.sh

cp -p /tmp/*-lms_cpuq.txt $output_dir/.
rm -f /tmp/*-lms_cpuq.txt

cd $output_dir
grep 'LMSCPU: LMS-[0-9][0-9][0-9][0-9][0-9]: WARNING:' *-lms_cpuq.txt  >$log_dir/LMSCPU_warnings.log
grep 'LMSCPU: LMS-[0-9][0-9][0-9][0-9][0-9]: ERROR:' *-lms_cpuq.txt  >$log_dir/LMSCPU_errors.log
grep 'Machine Name=' *-lms_cpuq.txt | sed 's/Machine Name=/LMSCPU: LMS-01000: COLLECTED: Machine Name: /g' >$log_dir/LMSCPU_collected.log

for log in `ls $log_dir/LMSCPU_*.log`
do
if [ ! -s $log ]; then
	rm -f $log
fi
done 

cd "$current_dir"